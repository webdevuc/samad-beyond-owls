import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tokenstats',
  templateUrl: './tokenstats.component.html',
  styleUrls: ['./tokenstats.component.scss']
})
export class TokenstatsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
