import { Component, OnInit } from '@angular/core';
import { LiquidityEventData } from 'src/app/models/liquidity-event-data';
import { LiquidityContractService } from 'src/app/services/liquidity-contract.service';
import { LocalDataUpdateService } from 'src/app/services/local-data-update.service';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-liquidity',
  templateUrl: './liquidity.component.html',
  styleUrls: ['./liquidity.component.scss']
})
export class LiquidityComponent implements OnInit {

  liquidityEventData: LiquidityEventData;
  timeLeft: string;
  eventIsClosed: boolean;
  claimableAmount = 0;

  constructor(private sharedService: SharedService,
              private liquidityContractService: LiquidityContractService,
              private localDataUpdateService: LocalDataUpdateService) { }

  ngOnInit() {
    this.tokenTimer();
    this.liquidityContractService.getLiquidityEventData().then(value => this.liquidityEventData = value!);
    this.localDataUpdateService.isClaimableAmountDataUpdated.subscribe(() => {
      this.liquidityContractService.getClaimableAmount().then(value => {
        if (value) {
          this.claimableAmount = value;
        }
      });
    });
  }

  tokenTimer() {
    this.timeLeft = this.sharedService.getTimeLeft(this.sharedService.endTime);
    const intervalId = setInterval(() => {
      this.timeLeft = this.sharedService.getTimeLeft(this.sharedService.endTime);
      if (this.timeLeft == 'EXPIRED') {
        this.eventIsClosed = true;
        clearInterval(intervalId);
      }
    }, 1000);
  }

  claimGriseToken() {
    if (this.eventIsClosed && this.claimableAmount > 0) {
      this.liquidityContractService.claimGriseToken();
    }
  }
}
