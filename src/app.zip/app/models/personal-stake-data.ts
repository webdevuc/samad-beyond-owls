export class PersonalStakeData {
    periodValue: number;
    stakeValue: number;
    stakeType: number;
    days: number;
}
