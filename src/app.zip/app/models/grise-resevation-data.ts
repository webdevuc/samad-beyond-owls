export class GriseReservationData {
    currentLPDay: number;
    slotsUsed: number;
    totalInvestment: number;
    myContribution: number;
    myShare:number;
}
