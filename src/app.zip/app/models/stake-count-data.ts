export class StakeCountData {
    stStakeCount: number;
    mt3MonthStakeCount: number;
    mt6MonthStakeCount: number;
    mt9MonthStakeCount: number;
    ltStakeCount: number;
    mtStakeCount: number;
    totalStakeCount: number;
}
