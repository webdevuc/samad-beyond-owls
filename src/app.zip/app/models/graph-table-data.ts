export class GraphTableData {
    totalMarketCap: number;
    circulatingSupply: number;
    initialPrice: number;
    currentPrice: number;
    roiOnInitalPrice: number;
    factorOnInitialPrice: number;
}
