export class LiquidityEventData {
    totalInvestment: number;
    uniqueInvestorCount: number;
    referralAccountCount: number;
    currentLPDay: number;
}
