export class RefundHistoryData {
    sponsoredAmount: number;
    myRefundAmount: number;
}
