export class PersonalPeriodStakeSetup {
    periodType: string;
    additionalValue: string;
    stakeStep: number;
    slotLeft: number;
}
