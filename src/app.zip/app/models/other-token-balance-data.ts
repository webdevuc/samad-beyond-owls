export class OtherTokenBalanceData {
    tokenLargeBalance: number;
    decimalPlaces: number;
    tokenShortBalance: number;
    regularRate: number;
    reverseRate: number;
}
