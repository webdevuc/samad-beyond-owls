export class ExchangeRateData {
    regularRate: number;
    reverseRate: number;
    reverseRateWithoutDecimal: number;
}
