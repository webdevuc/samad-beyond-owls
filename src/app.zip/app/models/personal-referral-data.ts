export class PersonalReferralData {
    referralAmount: number;
    referralTokens: number;
}
