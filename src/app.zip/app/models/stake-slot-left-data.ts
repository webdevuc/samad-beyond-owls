export class StakeSlotLeftData {
    stSlotLeft: number;
    mt3MonthSlotLeft: number;
    mt6MonthSlotLeft: number;
    mt9MonthSlotLeft: number;
    ltSlotLeft: number;
    mtSlotLeft: number;
    totalSlotLeft: number;
}
