export class StakeTransactionRewardData {
    transcRewardAmount: number;
    penaltyRewardAmount: number;
    reservoirRewardAmount: number;
    inflationRewardAmount: number;
}
